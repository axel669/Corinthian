(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
"use strict";

var _ReactRouter = ReactRouter;
var Route = _ReactRouter.Route;

var Main = function Main() {
    return React.createElement(
        UI.Screen,
        { title: "CARD Notifications" },
        React.createElement(
            UI.CenterContent,
            { height: 75, width: "100%" },
            App.settings.get("lastEmail", "Device not registered"),
            React.createElement(UI.Button, { block: true, raised: true, text: "Register Device", onTap: function () {
                    return App.transitionTo("/register");
                } })
        )
    );
};

var PINDisplay = function PINDisplay(_ref) {
    var _ref$pin = _ref.pin;
    var pin = _ref$pin === undefined ? '' : _ref$pin;
    var update = _ref.update;

    var updatePIN = function updatePIN(n) {
        return update("" + pin + n);
    };
    return React.createElement(
        "div",
        null,
        React.createElement(
            UI.CenterContent,
            { height: 30, width: "100%" },
            pin
        ),
        React.createElement(
            "div",
            { style: { margin: 'auto', width: 240 } },
            React.createElement(
                UI.Grid,
                { rowCount: 4, colCount: 3, width: 240, height: 240 },
                factotum.range(9, function (n) {
                    return React.createElement(UI.Button, { flush: true, fill: true, text: n + 1, onTap: function () {
                            return updatePIN(n + 1);
                        } });
                }),
                React.createElement(UI.Button, { flush: true, fill: true, text: "Clear", onTap: function () {
                        return update("");
                    } }),
                React.createElement(UI.Button, { flush: true, fill: true, text: "0", onTap: function () {
                        return updatePIN(0);
                    } })
            )
        )
    );
};

var RegisterScreen = React.createClass({
    displayName: "RegisterScreen",

    getInitialState: function getInitialState() {
        return {
            displayPIN: false,
            pin: '',
            serialNumber: null
        };
    },
    checkPin: function checkPin(email) {
        var displayPIN = this.state.displayPIN;

        switch (true) {
            case email === 'thxnoid@centerforautism.com':
                this.setState({ displayPIN: true });
                break;

            case displayPIN === true:
                this.setState({ displayPIN: false });
                break;
        }
        return email;
    },
    detectSerial: function detectSerial() {
        this.setState({ serialNumber: 'testing?' });
    },
    register: function register(info) {
        console.log(info);
    },
    render: function render() {
        var _this = this;

        var _state = this.state;
        var displayPIN = _state.displayPIN;
        var pin = _state.pin;
        var serialNumber = _state.serialNumber;

        var pinElement = undefined;
        var pwPlaceholder = undefined;
        var serial = undefined;

        if (serialNumber === null) {
            serial = "Read Clipboard for Serial#";
        } else {
            serial = serialNumber;
        }

        if (displayPIN === true) {
            pinElement = React.createElement(
                UI.Card,
                null,
                React.createElement(
                    "div",
                    { style: { textAlign: 'center' } },
                    React.createElement(UI.Button, { raised: true, text: serial, onTap: this.detectSerial })
                ),
                React.createElement(PINDisplay, { pin: pin, update: function (pin) {
                        return _this.setState({ pin: pin });
                    } })
            );
            pwPlaceholder = 'Serial Number';
        } else {
            pwPlaceholder = 'Password';
        }

        return React.createElement(
            UI.Screen,
            { title: "Register Device", back: "Cancel" },
            React.createElement(
                "div",
                { style: { maxWidth: 480, margin: 'auto' } },
                React.createElement(
                    UI.Card,
                    null,
                    React.createElement(
                        UI.Form,
                        { submitText: "Reigster", onSubmit: this.register },
                        React.createElement(UI.Item, { name: "email", inputType: "text", format: this.checkPin, placeholder: "Email" }),
                        React.createElement(UI.Item, { name: "password", inputType: "text", type: "password", placeholder: "Password" })
                    )
                ),
                pinElement
            )
        );
    }
});

App.start(React.createElement(
    Route,
    null,
    React.createElement(Route, { path: "/", component: Main }),
    React.createElement(Route, { path: "/register", component: RegisterScreen })
));

},{}]},{},[1])
//# sourceMappingURL=data:application/json;charset:utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyaWZ5L25vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJDOi9Vc2Vycy9BeGVsMS9Eb2N1bWVudHMvcHJvZ3JhbW1pbmcvanMvd2ViL2FwcC1iYXNlL2pzL21haW4uanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7OzttQkNBZ0IsV0FBVztJQUFwQixLQUFLLGdCQUFMLEtBQUs7O0FBRVosSUFBTSxJQUFJLEdBQUcsU0FBUCxJQUFJLEdBQVM7QUFDZixXQUNJO0FBQUMsVUFBRSxDQUFDLE1BQU07VUFBQyxLQUFLLEVBQUMsb0JBQW9CO1FBQ2pDO0FBQUMsY0FBRSxDQUFDLGFBQWE7Y0FBQyxNQUFNLEVBQUUsRUFBRSxBQUFDLEVBQUMsS0FBSyxFQUFDLE1BQU07WUFDckMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLHVCQUF1QixDQUFDO1lBQ3ZELG9CQUFDLEVBQUUsQ0FBQyxNQUFNLElBQUMsS0FBSyxNQUFBLEVBQUMsTUFBTSxNQUFBLEVBQUMsSUFBSSxFQUFDLGlCQUFpQixFQUFDLEtBQUssRUFBRTsyQkFBTSxHQUFHLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQztpQkFBQSxBQUFDLEdBQUc7U0FDOUU7S0FDWCxDQUNkO0NBQ0wsQ0FBQzs7QUFFRixJQUFNLFVBQVUsR0FBRyxTQUFiLFVBQVUsQ0FBSSxJQUFrQixFQUFLO21CQUF2QixJQUFrQixDQUFqQixHQUFHO1FBQUgsR0FBRyw0QkFBRyxFQUFFO1FBQUUsTUFBTSxHQUFqQixJQUFrQixDQUFQLE1BQU07O0FBQ2pDLFFBQU0sU0FBUyxHQUFHLFNBQVosU0FBUyxDQUFHLENBQUM7ZUFBSSxNQUFNLE1BQUksR0FBRyxHQUFHLENBQUMsQ0FBRztLQUFBLENBQUM7QUFDNUMsV0FDSTs7O1FBQ0k7QUFBQyxjQUFFLENBQUMsYUFBYTtjQUFDLE1BQU0sRUFBRSxFQUFFLEFBQUMsRUFBQyxLQUFLLEVBQUMsTUFBTTtZQUFFLEdBQUc7U0FBb0I7UUFDbkU7O2NBQUssS0FBSyxFQUFFLEVBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFDLEFBQUM7WUFDckM7QUFBQyxrQkFBRSxDQUFDLElBQUk7a0JBQUMsUUFBUSxFQUFFLENBQUMsQUFBQyxFQUFDLFFBQVEsRUFBRSxDQUFDLEFBQUMsRUFBQyxLQUFLLEVBQUUsR0FBRyxBQUFDLEVBQUMsTUFBTSxFQUFFLEdBQUcsQUFBQztnQkFDdEQsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsVUFBQSxDQUFDOzJCQUFJLG9CQUFDLEVBQUUsQ0FBQyxNQUFNLElBQUMsS0FBSyxNQUFBLEVBQUMsSUFBSSxNQUFBLEVBQUMsSUFBSSxFQUFFLENBQUMsR0FBRyxDQUFDLEFBQUMsRUFBQyxLQUFLLEVBQUU7bUNBQU0sU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7eUJBQUEsQUFBQyxHQUFHO2lCQUFBLENBQUM7Z0JBQzdGLG9CQUFDLEVBQUUsQ0FBQyxNQUFNLElBQUMsS0FBSyxNQUFBLEVBQUMsSUFBSSxNQUFBLEVBQUMsSUFBSSxFQUFDLE9BQU8sRUFBQyxLQUFLLEVBQUU7K0JBQU0sTUFBTSxDQUFDLEVBQUUsQ0FBQztxQkFBQSxBQUFDLEdBQUc7Z0JBQzlELG9CQUFDLEVBQUUsQ0FBQyxNQUFNLElBQUMsS0FBSyxNQUFBLEVBQUMsSUFBSSxNQUFBLEVBQUMsSUFBSSxFQUFDLEdBQUcsRUFBQyxLQUFLLEVBQUU7K0JBQU0sU0FBUyxDQUFDLENBQUMsQ0FBQztxQkFBQSxBQUFDLEdBQUc7YUFDdEQ7U0FDUjtLQUNKLENBQ1I7Q0FDTCxDQUFDOztBQUVGLElBQU0sY0FBYyxHQUFHLEtBQUssQ0FBQyxXQUFXLENBQUM7OztBQUNyQyxtQkFBZSxFQUFBLDJCQUFHO0FBQ2QsZUFBTztBQUNILHNCQUFVLEVBQUUsS0FBSztBQUNqQixlQUFHLEVBQUUsRUFBRTtBQUNQLHdCQUFZLEVBQUUsSUFBSTtTQUNyQixDQUFDO0tBQ0w7QUFDRCxZQUFRLEVBQUEsa0JBQUMsS0FBSyxFQUFFO1lBQ0wsVUFBVSxHQUFJLElBQUksQ0FBQyxLQUFLLENBQXhCLFVBQVU7O0FBRWpCLGdCQUFRLElBQUk7QUFDUixpQkFBTSxLQUFLLEtBQUssNkJBQTZCO0FBQ3pDLG9CQUFJLENBQUMsUUFBUSxDQUFDLEVBQUMsVUFBVSxFQUFFLElBQUksRUFBQyxDQUFDLENBQUM7QUFDbEMsc0JBQU07O0FBQUEsQUFFVixpQkFBTSxVQUFVLEtBQUssSUFBSTtBQUNyQixvQkFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFDLFVBQVUsRUFBRSxLQUFLLEVBQUMsQ0FBQyxDQUFDO0FBQ25DLHNCQUFNO0FBQUEsU0FDYjtBQUNELGVBQU8sS0FBSyxDQUFDO0tBQ2hCO0FBQ0QsZ0JBQVksRUFBQSx3QkFBRztBQUNYLFlBQUksQ0FBQyxRQUFRLENBQUMsRUFBQyxZQUFZLEVBQUUsVUFBVSxFQUFDLENBQUMsQ0FBQztLQUM3QztBQUNELFlBQVEsRUFBQSxrQkFBQyxJQUFJLEVBQUU7QUFDWCxlQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO0tBQ3JCO0FBQ0QsVUFBTSxFQUFBLGtCQUFHOzs7cUJBQ21DLElBQUksQ0FBQyxLQUFLO1lBQTNDLFVBQVUsVUFBVixVQUFVO1lBQUUsR0FBRyxVQUFILEdBQUc7WUFBRSxZQUFZLFVBQVosWUFBWTs7QUFDcEMsWUFBSSxVQUFVLFlBQUEsQ0FBQztBQUNmLFlBQUksYUFBYSxZQUFBLENBQUM7QUFDbEIsWUFBSSxNQUFNLFlBQUEsQ0FBQzs7QUFFWCxZQUFJLFlBQVksS0FBSyxJQUFJLEVBQUU7QUFDdkIsa0JBQU0sR0FBRyw0QkFBNEIsQ0FBQztTQUN6QyxNQUFNO0FBQ0gsa0JBQU0sR0FBRyxZQUFZLENBQUM7U0FDekI7O0FBRUQsWUFBSSxVQUFVLEtBQUssSUFBSSxFQUFFO0FBQ3JCLHNCQUFVLEdBQ047QUFBQyxrQkFBRSxDQUFDLElBQUk7O2dCQUNKOztzQkFBSyxLQUFLLEVBQUUsRUFBQyxTQUFTLEVBQUUsUUFBUSxFQUFDLEFBQUM7b0JBQzlCLG9CQUFDLEVBQUUsQ0FBQyxNQUFNLElBQUMsTUFBTSxNQUFBLEVBQUMsSUFBSSxFQUFFLE1BQU0sQUFBQyxFQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsWUFBWSxBQUFDLEdBQUc7aUJBQzFEO2dCQUNOLG9CQUFDLFVBQVUsSUFBQyxHQUFHLEVBQUUsR0FBRyxBQUFDLEVBQUMsTUFBTSxFQUFFLFVBQUEsR0FBRzsrQkFBSSxNQUFLLFFBQVEsQ0FBQyxFQUFDLEdBQUcsRUFBSCxHQUFHLEVBQUMsQ0FBQztxQkFBQSxBQUFDLEdBQUc7YUFDdkQsQUFDYixDQUFDO0FBQ0YseUJBQWEsR0FBRyxlQUFlLENBQUM7U0FDbkMsTUFBTTtBQUNILHlCQUFhLEdBQUcsVUFBVSxDQUFDO1NBQzlCOztBQUVELGVBQ0k7QUFBQyxjQUFFLENBQUMsTUFBTTtjQUFDLEtBQUssRUFBQyxpQkFBaUIsRUFBQyxJQUFJLEVBQUMsUUFBUTtZQUM1Qzs7a0JBQUssS0FBSyxFQUFFLEVBQUMsUUFBUSxFQUFFLEdBQUcsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFDLEFBQUM7Z0JBQ3hDO0FBQUMsc0JBQUUsQ0FBQyxJQUFJOztvQkFDSjtBQUFDLDBCQUFFLENBQUMsSUFBSTswQkFBQyxVQUFVLEVBQUMsVUFBVSxFQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUSxBQUFDO3dCQUNuRCxvQkFBQyxFQUFFLENBQUMsSUFBSSxJQUFDLElBQUksRUFBQyxPQUFPLEVBQUMsU0FBUyxFQUFDLE1BQU0sRUFBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFFBQVEsQUFBQyxFQUFDLFdBQVcsRUFBQyxPQUFPLEdBQUc7d0JBQ3BGLG9CQUFDLEVBQUUsQ0FBQyxJQUFJLElBQUMsSUFBSSxFQUFDLFVBQVUsRUFBQyxTQUFTLEVBQUMsTUFBTSxFQUFDLElBQUksRUFBQyxVQUFVLEVBQUMsV0FBVyxFQUFDLFVBQVUsR0FBRztxQkFDN0U7aUJBQ0o7Z0JBQ1QsVUFBVTthQUNUO1NBQ0UsQ0FDZDtLQUNMO0NBQ0osQ0FBQyxDQUFDOztBQUVILEdBQUcsQ0FBQyxLQUFLLENBQ0w7QUFBQyxTQUFLOztJQUNGLG9CQUFDLEtBQUssSUFBQyxJQUFJLEVBQUMsR0FBRyxFQUFDLFNBQVMsRUFBRSxJQUFJLEFBQUMsR0FBRztJQUNuQyxvQkFBQyxLQUFLLElBQUMsSUFBSSxFQUFDLFdBQVcsRUFBQyxTQUFTLEVBQUUsY0FBYyxBQUFDLEdBQUc7Q0FDakQsQ0FDWCxDQUFDIiwiZmlsZSI6ImdlbmVyYXRlZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzQ29udGVudCI6WyIoZnVuY3Rpb24gZSh0LG4scil7ZnVuY3Rpb24gcyhvLHUpe2lmKCFuW29dKXtpZighdFtvXSl7dmFyIGE9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtpZighdSYmYSlyZXR1cm4gYShvLCEwKTtpZihpKXJldHVybiBpKG8sITApO3ZhciBmPW5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIrbytcIidcIik7dGhyb3cgZi5jb2RlPVwiTU9EVUxFX05PVF9GT1VORFwiLGZ9dmFyIGw9bltvXT17ZXhwb3J0czp7fX07dFtvXVswXS5jYWxsKGwuZXhwb3J0cyxmdW5jdGlvbihlKXt2YXIgbj10W29dWzFdW2VdO3JldHVybiBzKG4/bjplKX0sbCxsLmV4cG9ydHMsZSx0LG4scil9cmV0dXJuIG5bb10uZXhwb3J0c312YXIgaT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2Zvcih2YXIgbz0wO288ci5sZW5ndGg7bysrKXMocltvXSk7cmV0dXJuIHN9KSIsImNvbnN0IHtSb3V0ZX0gPSBSZWFjdFJvdXRlcjtcblxuY29uc3QgTWFpbiA9ICgpID0+IHtcbiAgICByZXR1cm4gKFxuICAgICAgICA8VUkuU2NyZWVuIHRpdGxlPVwiQ0FSRCBOb3RpZmljYXRpb25zXCI+XG4gICAgICAgICAgICA8VUkuQ2VudGVyQ29udGVudCBoZWlnaHQ9ezc1fSB3aWR0aD1cIjEwMCVcIj5cbiAgICAgICAgICAgICAgICB7QXBwLnNldHRpbmdzLmdldChcImxhc3RFbWFpbFwiLCBcIkRldmljZSBub3QgcmVnaXN0ZXJlZFwiKX1cbiAgICAgICAgICAgICAgICA8VUkuQnV0dG9uIGJsb2NrIHJhaXNlZCB0ZXh0PVwiUmVnaXN0ZXIgRGV2aWNlXCIgb25UYXA9eygpID0+IEFwcC50cmFuc2l0aW9uVG8oXCIvcmVnaXN0ZXJcIil9IC8+XG4gICAgICAgICAgICA8L1VJLkNlbnRlckNvbnRlbnQ+XG4gICAgICAgIDwvVUkuU2NyZWVuPlxuICAgICk7XG59O1xuXG5jb25zdCBQSU5EaXNwbGF5ID0gKHtwaW4gPSAnJywgdXBkYXRlfSkgPT4ge1xuICAgIGNvbnN0IHVwZGF0ZVBJTiA9IG4gPT4gdXBkYXRlKGAke3Bpbn0ke259YCk7XG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxVSS5DZW50ZXJDb250ZW50IGhlaWdodD17MzB9IHdpZHRoPVwiMTAwJVwiPntwaW59PC9VSS5DZW50ZXJDb250ZW50PlxuICAgICAgICAgICAgPGRpdiBzdHlsZT17e21hcmdpbjogJ2F1dG8nLCB3aWR0aDogMjQwfX0+XG4gICAgICAgICAgICAgICAgPFVJLkdyaWQgcm93Q291bnQ9ezR9IGNvbENvdW50PXszfSB3aWR0aD17MjQwfSBoZWlnaHQ9ezI0MH0+XG4gICAgICAgICAgICAgICAgICAgIHtmYWN0b3R1bS5yYW5nZSg5LCBuID0+IDxVSS5CdXR0b24gZmx1c2ggZmlsbCB0ZXh0PXtuICsgMX0gb25UYXA9eygpID0+IHVwZGF0ZVBJTihuICsgMSl9IC8+KX1cbiAgICAgICAgICAgICAgICAgICAgPFVJLkJ1dHRvbiBmbHVzaCBmaWxsIHRleHQ9XCJDbGVhclwiIG9uVGFwPXsoKSA9PiB1cGRhdGUoXCJcIil9IC8+XG4gICAgICAgICAgICAgICAgICAgIDxVSS5CdXR0b24gZmx1c2ggZmlsbCB0ZXh0PVwiMFwiIG9uVGFwPXsoKSA9PiB1cGRhdGVQSU4oMCl9IC8+XG4gICAgICAgICAgICAgICAgPC9VSS5HcmlkPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59O1xuXG5jb25zdCBSZWdpc3RlclNjcmVlbiA9IFJlYWN0LmNyZWF0ZUNsYXNzKHtcbiAgICBnZXRJbml0aWFsU3RhdGUoKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBkaXNwbGF5UElOOiBmYWxzZSxcbiAgICAgICAgICAgIHBpbjogJycsXG4gICAgICAgICAgICBzZXJpYWxOdW1iZXI6IG51bGxcbiAgICAgICAgfTtcbiAgICB9LFxuICAgIGNoZWNrUGluKGVtYWlsKSB7XG4gICAgICAgIGNvbnN0IHtkaXNwbGF5UElOfSA9IHRoaXMuc3RhdGU7XG5cbiAgICAgICAgc3dpdGNoICh0cnVlKSB7XG4gICAgICAgICAgICBjYXNlIChlbWFpbCA9PT0gJ3RoeG5vaWRAY2VudGVyZm9yYXV0aXNtLmNvbScpOlxuICAgICAgICAgICAgICAgIHRoaXMuc2V0U3RhdGUoe2Rpc3BsYXlQSU46IHRydWV9KTtcbiAgICAgICAgICAgICAgICBicmVhaztcblxuICAgICAgICAgICAgY2FzZSAoZGlzcGxheVBJTiA9PT0gdHJ1ZSk6XG4gICAgICAgICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7ZGlzcGxheVBJTjogZmFsc2V9KTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZW1haWw7XG4gICAgfSxcbiAgICBkZXRlY3RTZXJpYWwoKSB7XG4gICAgICAgIHRoaXMuc2V0U3RhdGUoe3NlcmlhbE51bWJlcjogJ3Rlc3Rpbmc/J30pO1xuICAgIH0sXG4gICAgcmVnaXN0ZXIoaW5mbykge1xuICAgICAgICBjb25zb2xlLmxvZyhpbmZvKTtcbiAgICB9LFxuICAgIHJlbmRlcigpIHtcbiAgICAgICAgY29uc3Qge2Rpc3BsYXlQSU4sIHBpbiwgc2VyaWFsTnVtYmVyfSA9IHRoaXMuc3RhdGU7XG4gICAgICAgIGxldCBwaW5FbGVtZW50O1xuICAgICAgICBsZXQgcHdQbGFjZWhvbGRlcjtcbiAgICAgICAgbGV0IHNlcmlhbDtcblxuICAgICAgICBpZiAoc2VyaWFsTnVtYmVyID09PSBudWxsKSB7XG4gICAgICAgICAgICBzZXJpYWwgPSBcIlJlYWQgQ2xpcGJvYXJkIGZvciBTZXJpYWwjXCI7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzZXJpYWwgPSBzZXJpYWxOdW1iZXI7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoZGlzcGxheVBJTiA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgcGluRWxlbWVudCA9IChcbiAgICAgICAgICAgICAgICA8VUkuQ2FyZD5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17e3RleHRBbGlnbjogJ2NlbnRlcid9fT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxVSS5CdXR0b24gcmFpc2VkIHRleHQ9e3NlcmlhbH0gb25UYXA9e3RoaXMuZGV0ZWN0U2VyaWFsfSAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPFBJTkRpc3BsYXkgcGluPXtwaW59IHVwZGF0ZT17cGluID0+IHRoaXMuc2V0U3RhdGUoe3Bpbn0pfSAvPlxuICAgICAgICAgICAgICAgIDwvVUkuQ2FyZD5cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBwd1BsYWNlaG9sZGVyID0gJ1NlcmlhbCBOdW1iZXInO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcHdQbGFjZWhvbGRlciA9ICdQYXNzd29yZCc7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgPFVJLlNjcmVlbiB0aXRsZT1cIlJlZ2lzdGVyIERldmljZVwiIGJhY2s9XCJDYW5jZWxcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7bWF4V2lkdGg6IDQ4MCwgbWFyZ2luOiAnYXV0byd9fT5cbiAgICAgICAgICAgICAgICAgICAgPFVJLkNhcmQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8VUkuRm9ybSBzdWJtaXRUZXh0PVwiUmVpZ3N0ZXJcIiBvblN1Ym1pdD17dGhpcy5yZWdpc3Rlcn0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFVJLkl0ZW0gbmFtZT1cImVtYWlsXCIgaW5wdXRUeXBlPVwidGV4dFwiIGZvcm1hdD17dGhpcy5jaGVja1Bpbn0gcGxhY2Vob2xkZXI9XCJFbWFpbFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFVJLkl0ZW0gbmFtZT1cInBhc3N3b3JkXCIgaW5wdXRUeXBlPVwidGV4dFwiIHR5cGU9XCJwYXNzd29yZFwiIHBsYWNlaG9sZGVyPVwiUGFzc3dvcmRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9VSS5Gb3JtPlxuICAgICAgICAgICAgICAgICAgICA8L1VJLkNhcmQ+XG4gICAgICAgICAgICAgICAgICAgIHtwaW5FbGVtZW50fVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9VSS5TY3JlZW4+XG4gICAgICAgICk7XG4gICAgfVxufSk7XG5cbkFwcC5zdGFydChcbiAgICA8Um91dGU+XG4gICAgICAgIDxSb3V0ZSBwYXRoPVwiL1wiIGNvbXBvbmVudD17TWFpbn0gLz5cbiAgICAgICAgPFJvdXRlIHBhdGg9XCIvcmVnaXN0ZXJcIiBjb21wb25lbnQ9e1JlZ2lzdGVyU2NyZWVufSAvPlxuICAgIDwvUm91dGU+XG4pO1xuIl19
